package com.example.ejerciciointerfazgraficauno;

import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.*;

public class HelloController {
    @FXML
    private Label welcomeText;

    @FXML
    private Label ApacheText;

    @FXML
    private Label pidApache;

    @FXML
    private Label pidMaria;

    private Process processRunninga;
    private Process processRunningm;

    String nomHost = "127.0.0.1";

    int numPuerto = 8000;

    String COD_TEXTO = "UTF-8";

    @FXML
    protected void onApacheButtonClickOn() {

        try (DatagramSocket clientSocket = new DatagramSocket()) {
            InetAddress IPServidor = InetAddress.getByName(nomHost);
            String lineaLeida = "runApache";

            byte[] b = lineaLeida.getBytes(COD_TEXTO);

            DatagramPacket paqueteEnviado = new DatagramPacket(b, b.length, IPServidor, numPuerto);

            clientSocket.connect(IPServidor, numPuerto);

            clientSocket.send(paqueteEnviado);
        } catch (Exception e){
            e.printStackTrace();
        }


        /*Task abrir = new Task() {
            @Override
            protected Object call() throws Exception {
                String[] comando = {"service","apache2","start"};
                ProcessBuilder pb = new ProcessBuilder(comando);
                pb.inheritIO();
                try {
                    Process p = pb.start();
                    p.waitFor();
                    updateMessage(String.valueOf(p.pid()));
                    processRunninga = p;

                } catch (InterruptedException | IOException e) {
                    e.printStackTrace();
                }
                return null;
            }
        };

        Thread t = new Thread(abrir);

        t.start();

        pidApache.textProperty().bind(abrir.messageProperty());*/

    }

    @FXML
    protected void onApacheGetStatus() {
        try (DatagramSocket clientSocket = new DatagramSocket()) {
            InetAddress IPServidor = InetAddress.getByName(nomHost);
            String lineaLeida = "statusApache";
            byte[] buffer = new byte[5];
            byte[] b = lineaLeida.getBytes(COD_TEXTO);
            DatagramSocket socketUDP = new DatagramSocket();

            DatagramPacket paqueteEnviado = new DatagramPacket(b, b.length, IPServidor, numPuerto);

            clientSocket.connect(IPServidor, numPuerto);

            clientSocket.send(paqueteEnviado);
            DatagramPacket peticion = new DatagramPacket(buffer, buffer.length);
            clientSocket.receive(peticion);

            String mensaje = new String(peticion.getData());
            if (mensaje.equals("false")){
                pidApache.setText("DEAD");
            } else{
                pidApache.setText("RUNNING");
            }

        } catch (Exception e){
            e.printStackTrace();
        }

    }

    @FXML
    protected void onApacheButtonClickKill() {

        try (DatagramSocket clientSocket = new DatagramSocket()) {
            InetAddress IPServidor = InetAddress.getByName(nomHost);
            String lineaLeida = "stopApache";

            byte[] b = lineaLeida.getBytes(COD_TEXTO);

            DatagramPacket paqueteEnviado = new DatagramPacket(b, b.length, IPServidor, numPuerto);

            clientSocket.connect(IPServidor, numPuerto);

            clientSocket.send(paqueteEnviado);
        } catch (Exception e){
            e.printStackTrace();
        }


        /*Task kill = new Task() {
            @Override
            protected Object call() throws Exception {
                String[] comando = {"/etc/init.d/apache2","stop"};
                Thread hilo = new Thread();
                ProcessBuilder pb = new ProcessBuilder(comando);
                pb.inheritIO();
                try {
                    Process p = pb.start();
                    p.waitFor();
                } catch (InterruptedException | IOException e) {
                    e.printStackTrace();
                }
                return null;
            }
        };

        Thread t = new Thread(kill);

        t.start();*/
    }

    @FXML
    protected void onMariaButtonClickOn() {

        try (DatagramSocket clientSocket = new DatagramSocket()) {
            InetAddress IPServidor = InetAddress.getByName(nomHost);
            String lineaLeida = "runMariaDB";

            byte[] b = lineaLeida.getBytes(COD_TEXTO);

            DatagramPacket paqueteEnviado = new DatagramPacket(b, b.length, IPServidor, numPuerto);

            clientSocket.connect(IPServidor, numPuerto);

            clientSocket.send(paqueteEnviado);
        } catch (Exception e){
            e.printStackTrace();
        }


        /*Task abrir = new Task() {
            @Override
            protected Object call() throws Exception {
                String[] comando = {"service","mysql","start"};
                ProcessBuilder pb = new ProcessBuilder(comando);
                pb.inheritIO();
                try {
                    Process p = pb.start();
                    p.waitFor();
                    updateMessage(String.valueOf(p.pid()));
                    processRunningm = p;

                } catch (InterruptedException | IOException e) {
                    e.printStackTrace();
                }
                return null;
            }
        };

        Thread t = new Thread(abrir);

        t.start();

        pidMaria.textProperty().bind(abrir.messageProperty());*/
    }

    @FXML
    protected void onMariaGetStatus() {
        System.out.println("hola");
        try (DatagramSocket clientSocket = new DatagramSocket()) {
            byte[] buffer = new byte[5];

            InetAddress IPServidor = InetAddress.getByName(nomHost);
            String lineaLeida = "statusMaria";

            byte[] b = lineaLeida.getBytes(COD_TEXTO);

            DatagramPacket paqueteEnviado = new DatagramPacket(b, b.length);

            clientSocket.connect(IPServidor, numPuerto);

            clientSocket.send(paqueteEnviado);
            DatagramPacket peticion = new DatagramPacket(buffer, buffer.length);
            clientSocket.receive(peticion);

            String mensaje = new String(peticion.getData());
            if (mensaje.equals("false")){
                pidMaria.setText("DEAD");
            } else{
                pidMaria.setText("RUNNING");
            }

        } catch (Exception e){
            e.printStackTrace();
        }



    }

    @FXML
    protected void onMariaButtonClickKill() {

        try (DatagramSocket clientSocket = new DatagramSocket()) {
            InetAddress IPServidor = InetAddress.getByName(nomHost);
            String lineaLeida = "stopMariaDB";

            byte[] b = lineaLeida.getBytes(COD_TEXTO);

            DatagramPacket paqueteEnviado = new DatagramPacket(b, b.length, IPServidor, numPuerto);

            clientSocket.connect(IPServidor, numPuerto);

            clientSocket.send(paqueteEnviado);
        } catch (Exception e){
            e.printStackTrace();
        }


        /*Task kill = new Task() {
            @Override
            protected Object call() throws Exception {
                String[] comando = {"/etc/init.d/mysql","stop"};
                Thread hilo = new Thread();
                ProcessBuilder pb = new ProcessBuilder(comando);
                pb.inheritIO();
                try {
                    Process p = pb.start();
                    p.waitFor();
                } catch (InterruptedException | IOException e) {
                    e.printStackTrace();
                }
                return null;
            }
        };

        Thread t = new Thread(kill);

        t.start();*/
    }

    @FXML
    protected void onRestartPC() {

        try (DatagramSocket clientSocket = new DatagramSocket()) {
            InetAddress IPServidor = InetAddress.getByName(nomHost);
            String lineaLeida = "restart";

            byte[] b = lineaLeida.getBytes(COD_TEXTO);

            DatagramPacket paqueteEnviado = new DatagramPacket(b, b.length, IPServidor, numPuerto);

            clientSocket.connect(IPServidor, numPuerto);

            clientSocket.send(paqueteEnviado);
        } catch (Exception e){
            e.printStackTrace();
        }



    }
}